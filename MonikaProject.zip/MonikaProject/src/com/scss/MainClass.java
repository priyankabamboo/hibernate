package com.scss;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MainClass {

	public static void main(String[] args) {
		Configuration cfg=new Configuration();
		cfg.configure("hiber.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session session=sf.openSession();
		Dept d=new Dept();
		d.setDeptid(11);
		d.setDeptname("It");
		Employee e=new Employee();
		e.setEmpid(123);
		e.setEmpname("riya");
		Employee e1=new Employee();
		e1.setEmpid(124);
		e1.setEmpname("jiya");
		Set st=new HashSet<>();
		st.add(e);
		st.add(e1);
		d.setEmpref(st);
		Transaction tx=session.beginTransaction();
		session.save(d);
		tx.commit();
		session.close();
		sf.close();
		
		
	}

}
