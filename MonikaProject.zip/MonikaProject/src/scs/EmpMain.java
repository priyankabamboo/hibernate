package scs;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class EmpMain {

	public static void main(String[] args) {
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session session=sf.openSession();
		Employee obj=new Employee();
		Scanner sc=new Scanner(System.in);
		System.out.println("enter id ");
		int id=sc.nextInt();
		System.out.println("enter name ");
		String name=sc.next();
		System.out.println("enter salary ");
		int salary=sc.nextInt();
		obj.setEmpid(id);
		obj.setEmpname(name);
		obj.setSalary(salary);
		Transaction tx=session.beginTransaction();
		session.save(obj);
		tx.commit();
		session.close();
		System.out.println("data submitted successfully");
		
		

	}

}
